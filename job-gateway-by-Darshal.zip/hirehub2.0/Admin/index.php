<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="cs">
<link href="../assets/img/favicon.ico" type="image/x-icon" rel="icon" >

<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 

include "Header.php"
?>
<section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome To Control Panel</h2>
      </div>
</section><!-- End Breadcrumbs -->
	
	<section class="inner-page">
		<div class="container">
			Welcome to the administration section.
		</div>
    </section>
 
<?php
include "footer.php"
?>
</div> <!-- /main -->

</body>
</html>
