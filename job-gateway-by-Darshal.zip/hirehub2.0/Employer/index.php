<!DOCTYPE html PUBLIC "-//W3C//Ddiv class="col-sm" XHTML 1.0 Sdiv class="row"ict//EN" "http://www.w3.org/div class="row"/xhtml1/Ddiv class="col-sm"/xhtml1-sdiv class="row"ict.ddiv class="col-sm"">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<link href="../assets/img/favicon.ico" type="image/x-icon" rel="icon" >

<body id="www-url-cz">

<div id="main" class="box">
<?php 
include "Header.php"
?>

    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome <?php echo $_SESSION['$UserName_emp'] ;?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<section class="inner-page">
      <div class="container">
                
                  <div class="row">
                    <div class="col-sm"><div align="center"><img src="design/Home.png" alt="" width="64" height="64" /></div></div>
                    <div class="col-sm"><div align="center"><img src="design/Profile.png" alt="" width="64" height="64" /></div></div>
                    <div class="col-sm"><div align="center"><img src="design/Search.png" alt="" width="64" height="64" /></div></div>
                  </div>
                  <div class="row">
                    <div class="col-sm"><div align="center"><a href="index.php">Home</a></div></div>
                    <div class="col-sm"><div align="center"><a href="Profile.php">Profile</a></div></div>
                    <div class="col-sm"><div align="center"><a href="ManageJob.php">Manage JOB</a></div></div>
                  </div>
				  <br><br>
                  <div class="row">
                    <div class="col-sm"><div align="center"><img src="design/Interview.png" alt="" width="64" height="64" /></div></div>
                    <div class="col-sm"><div align="center"><img src="design/Feedback.png" alt="" width="64" height="64" /></div></div >
                    <div class="col-sm"><div align="center"><img src="design/Log.png" alt="" width="64" height="64" /></div></div>
                  </div>
                  <div class="row">
                    <div class="col-sm" ><div align="center"><a href="ManageWalkin.php">Walkin</a></div></div>
                    <div class="col-sm" ><div align="center"><a href="Application.php">Application</a></div></div>
                    <div class="col-sm" ><div align="center"><a href="session_destroy.php">Logout</a></div></div>
                  </div>
                

          </div> <!-- /article -->
</section>
            
            
        </div> <!-- /content -->


    </div> <!-- /main -->
  

 
<?php
include "footer.php"
?>


</body>
</html>
