<title>Hire Hub</title>
<link rel="icon" href="../design/title.png" type="image/icon type">